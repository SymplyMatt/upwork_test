module.exports = {
  apps: [
    {
      name: "rentcart",
      script: '/data01/virt103469/domeenid/www.redautorent.ee/htdocs/redautorent.ee/server.js',
    }
  ]
};


