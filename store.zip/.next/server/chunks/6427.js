"use strict";
exports.id = 6427;
exports.ids = [6427];
exports.modules = {

/***/ 6427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AddressMap)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function AddressMap() {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: "iframe-map",
    dangerouslySetInnerHTML: {
      __html: `<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2031.1197725302327!2d24.667175216075087!3d59.39771418168285!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4692958c29320ebd%3A0x29f99a28a3b76640!2sRED%20AutoRent%20O%C3%9C!5e0!3m2!1sru!2sru!4v1623616043846!5m2!1sru!2sru" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>`
    }
  });
}

/***/ })

};
;